package test;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import APITest.Place;
import io.restassured.response.Response;

public class TestAPI  extends BaseTest{

	public String sentCoin="";
	public String receivedCoin="";
	public int sentCoinAmount=0 ;
	public int receivedCoinAmount=0;
	public int id=0;
	@Test(priority=1)
	public void postRequest() {
		
		Response response=given().log().all().header("Content-Type","application/json")
                .body(Place.AddPlace())
                .when()
                .post("transaction")
                .then()
                .extract().response();
		
		Assert.assertEquals(200, response.statusCode());
		 Assert.assertEquals("INT", response.jsonPath().getString("sentCoinAmount"));
	        Assert.assertEquals("USDT", response.jsonPath().getString("receivedCoinAmount"));
        Assert.assertEquals("300", response.jsonPath().getString("sentCoinAmount"));
        Assert.assertEquals("2", response.jsonPath().getString("receivedCoinAmount"));
        id=Integer.parseInt(response.jsonPath().getString("id"));
        sentCoin=response.jsonPath().getString("sentCoin");
        receivedCoin=response.jsonPath().getString("receivedCoin");
        sentCoinAmount=Integer.parseInt(response.jsonPath().getString("sentCoinAmount"));
        receivedCoinAmount=Integer.parseInt(response.jsonPath().getString("receivedCoinAmount"));
        System.out.println("Response:-"+response.getBody());
	}
	@Test(priority=2)
	public void getrequest()
	{
		
		Response getPlaceResponse=	given().log().all()
		.when().get("transaction/"+id)
		.then().assertThat().log().all().statusCode(200).extract().response();
		Assert.assertEquals(200, getPlaceResponse.statusCode());
		Assert.assertEquals(id, getPlaceResponse.jsonPath().getString("id"));
		Assert.assertEquals(sentCoin, getPlaceResponse.jsonPath().getString("sentCoinAmount"));
        Assert.assertEquals(receivedCoin, getPlaceResponse.jsonPath().getString("receivedCoinAmount"));
        Assert.assertEquals(sentCoinAmount, getPlaceResponse.jsonPath().getString("sentCoinAmount"));
        Assert.assertEquals(receivedCoinAmount, getPlaceResponse.jsonPath().getString("receivedCoinAmount"));
		int receivedCoinMarketPrice=0;
		receivedCoinMarketPrice= sentCoinAmount/receivedCoinAmount;
		Assert.assertEquals(receivedCoinMarketPrice, getPlaceResponse.jsonPath().getString("receivedCoinMarketPricei"));
		
		
		
	}
}
