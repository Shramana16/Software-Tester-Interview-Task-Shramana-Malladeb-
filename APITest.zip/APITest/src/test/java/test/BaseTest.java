package test;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class BaseTest {

	
	@BeforeMethod
	public void BaseUrl() {
		
		RestAssured.baseURI="https://x8ki-letl-twmt.n7.xano.io/api:gHPd8le5";
		
	}
	
}
