package APITest;



public class Place {

public static String AddPlace()
	
	{
		return "{\"coin1\": \"INR\",\r\n" + 
				"\"coin2\": \"USDT\",\r\n" + 
				"\"coin1Amount\": 300,\r\n" + 
				"\"coin2Amount\": 2"
				+ "}";
		
	}
}
